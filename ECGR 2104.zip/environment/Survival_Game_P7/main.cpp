#include <iostream>
#include <sstream>
#include <time.h>

using namespace std;

class Player {
    public:
    Player(int x, int y){
        health = MAX_HEALTH;
        hunger = MAX_HUNGER;
        thirst = MAX_THIRST;
        // armor;
        
        this->x = x;
        this->y = y;
        this->score = 0;
    }
    
    int getScore() const {
        return score;
    }
    
    void takeDamage(int val){
        this->health -= val;
        if(this->health < 0) this->health = 0;
    }
    
    void takeTurn(){
        this->thirst--;
        this->hunger--;
        
        if(this->thirst <= 0){
            this->health--;
            this->thirst = 0;
        }
        
        if(this->hunger <= 0){
            this->health--;
            this->hunger = 0;
        }
        
        this->score++;
    }
    
    string getStats() const {
        stringstream ss;
        ss  << "============\n"
            << "Health: " << this->health << "\n" 
            << "Hunger: " << this->hunger << "\n" 
            << "Thirst: " << this->thirst << "\n"
            << "Armor: " << this->armor << "\n"
            << "============\n";
        return ss.str();
    }
    
    bool isAlive() const {
        return this->health > 0;
    }
    
    void increaseThrist(int val){
        this->thirst = this->thirst + val;
        if(this->thirst > MAX_THIRST) this->thirst = MAX_THIRST;
    }
    
    void increaseHunger(int val){
        this->hunger += val;
        if(this->hunger > MAX_HUNGER) this->hunger = MAX_HUNGER;
    }
    
    void increaseArmor(int val){
        this->armor += val;
        if(this->armor > MAX_ARMOR) this->armor = MAX_ARMOR;
    }
    
    void increaseHealth(int val) {
        this->health += val;
        if(this->health > MAX_HEALTH) this->health = MAX_HEALTH;
    }
    
    void decreaseArmor(int val){
        this->armor -= val;
    }
    
    int getArmorNum() const {
        return this->armor;
    }
    
    int getHealth() const {
        return this->health;
    }
    
    int x, y;
    private:
    int health, hunger, thirst, score, armor;
    const int MAX_HEALTH = 3;
    const int MAX_HUNGER = 5;
    const int MAX_THIRST = 3;
    const int MAX_ARMOR = 4;
};

class Land {
    public:
    virtual string getDescription() = 0;
    virtual string visit(Player& player) = 0;
};

class Forest : public Land {
    public:
    string getDescription(){
        return "a densely wooded forest.";
    }
    
    string visit(Player& player){
        int randomNum = rand() % 100;
        
        if(randomNum > 74){
            if(player.getArmorNum() > 0){
                randomNum = rand() % 100;
                if (randomNum > player.getArmorNum() * 10){
                    player.takeDamage(1);
                    return "You are attached by a beer while foraging for berries. Your armor did not save you.";
                }
                else{
                    return "You are attacked by a beer while foraging for berries. Your armor saved you!!!";
                }
            }
            else{
                player.takeDamage(1);
                return "You are attacked by a bear while foraging for berries.";
            }
        } else {
            player.increaseHunger(2);
            return "You forage for berries in the woods and eat a few.";
        }
    }
};

class Lake : public Land {
    public:
    string getDescription(){
        return "a clear sparkling lake.";
    }
    
    string visit(Player& player){
        player.increaseThrist(2);
        return "You visit the lake and drink its clean water";
    }
};

class Cave : public Land {
    public:
    string getDescription(){
        return "a mysterious cave.";
    }
    
    string visit(Player& player){
        int randomNum = rand() % 100;
        
        if(player.getArmorNum() < 4){
            if(randomNum > 74){
                player.increaseArmor(1);
                return "You gained a piece of armor.";
            }
            else{
                return "Better luck next time.";
            }
        }
        else{
            return "You already have four pieces of armor.";
        }
    }
};

class House : public Land {
    public:
    string getDescription(){
        return "a strange house.";
    }
    
    string visit(Player& player){
        int randomNum = rand() % 100;
        cout << "You lay down in bed." << endl;
        
        if(randomNum > 24){
            player.increaseHunger(5);
            player.increaseThrist(5);
            return "You fall asleep and restore all hunger and thirst.";
        }
        else{
            player.takeDamage(1);
            return "You are attacked by bed bugs.";
        }
    }
};

class Village : public Land {
    public:
    char input;
    string getDescription(){
        return "a village.";
    }
    
    string visit(Player& player){
        if(player.getArmorNum() > 0 && player.getHealth() < 3){
            cout << "Would you like to trade a piece of armor for an extra life?(input Y/N)" << endl;
            cin >> input;
            input = toupper(input);
            if(input == 'Y'){
                player.decreaseArmor(1);
                player.increaseHealth(1);
                return "You traded one piece of armor for one health.";
            }
            else{
                return "You choose not to make the trade.";
            }
        }
        else{
            return "You do not have any armor to trade or you already have max health.";
        }
    }
};

class Casino : public Land {
    public:
    string getDescription(){
        return "an old casino.";
    }
    
    string visit(Player& player){
        int randomNum = rand() % 100;
        if (randomNum <= 32){
            player.increaseHealth(1);
            return "You spun an extra life.";
        }
        else if(randomNum > 33 && randomNum <= 65){
            player.increaseHunger(2);
            return "You spun two hunger.";
        }
        else{
            player.increaseThrist(2);
            return "You spun two thirst.";
        }
    }
};

class Desert : public Land {
    public:
    string getDescription(){
        return "a barren desert.";
    }
    
    string visit(Player& player){
        int randomNum = rand() % 100;
        if(randomNum > 74){
            if(player.getArmorNum() > 0){
                randomNum = rand() % 100;
                if (randomNum > player.getArmorNum() * 10){
                    player.takeDamage(1);
                    return "You are attached by a snake while roaming the desert. Your armor did not save you.";
                }
                else{
                    return "You are attacked by a snake while roaming the desert. Your armor saved you!!!";
                }
            }
            else{
                player.takeDamage(1);
                return "You are attacked by a snake while roaming the desert.";
            }
        }
        else{
            player.increaseThrist(2);
            return "You drank cactus water.";
        }
    }
};

class Pond : public Land {
    public:
    string getDescription(){
        return "a small pond.";
    }
    
    string visit(Player& player){
        int randomNum = rand() % 100;
        if(randomNum > 74){
            player.takeDamage(1);
            return "You fell in the pond and drowned.";
        }
        else{
            int randomNum = rand() % 100;
            if(randomNum > 49){
                player.increaseThrist(2);
                return "You dank some water.";
            }
            else{
                player.increaseHunger(2);
                return "You caught a fish and ate it.";
            }
        }
    }
};

const int MAP_SIZE = 10;
Land* map[MAP_SIZE][MAP_SIZE];

void populateMap(){
    for(int i = 0; i < MAP_SIZE; i++){
        for(int j = 0; j < MAP_SIZE; j++){
            int randomNum = rand() % 8;
            switch(randomNum){
                case 0: // Forest
                    map[i][j] = new Forest;
                    break;
                case 1: // Lake
                    map[i][j] = new Lake;
                    break;
                case 2: // Cave
                    map[i][j] = new Cave;
                    break;
                case 3: // House
                    map[i][j] = new House;
                    break;
                case 4: // Village
                    map[i][j] = new Village;
                    break;
                case 5: // Casino
                    map[i][j] = new Casino;
                    break;
                case 6: // Desert
                    map[i][j] = new Desert;
                    break;
                case 7: // Pond
                    map[i][j] = new Pond;
                    break;
                default:
                    cout << "Invalid land type selected" << endl;
                    break;
            }
        }
    }
}

int main(){
    srand(time(NULL));
    
    populateMap();
    
    Player player(MAP_SIZE/2, MAP_SIZE/2);
    
    cout << "You wake up and find yourself lost in the middle of a strange wilderness." << endl;
    
    while(player.isAlive()){
        cout << "To the north you see " << map[(player.x) % MAP_SIZE][(player.y - 1 + MAP_SIZE) % MAP_SIZE]->getDescription() << endl;
        cout << "To the east you see " << map[(player.x + 1) % MAP_SIZE][(player.y) % MAP_SIZE]->getDescription() << endl;
        cout << "To the south you see " << map[(player.x) % MAP_SIZE][(player.y + 1) % MAP_SIZE]->getDescription() << endl;
        cout << "To the west you see " << map[(player.x - 1 + MAP_SIZE) % MAP_SIZE][(player.y) % MAP_SIZE]->getDescription() << endl;
        
        cout << "Which way will you go? Enter N, E, S, or W:" << endl;
        char userInput;
        cin >> userInput;
        userInput = toupper(userInput);
        
        while(userInput != 'N' && userInput != 'E' && userInput != 'S' && userInput != 'W'){
            cout << "Input N, E, S, or W." << endl;
            cin >> userInput;
            userInput = toupper(userInput);
        }
        
        switch(userInput){
            case 'N':
                player.y = (player.y - 1 + MAP_SIZE) % MAP_SIZE;
                break;
            case 'E':
                player.x = (player.x + 1) % MAP_SIZE;
                break;
            case 'S':
                player.y = (player.y + 1) % MAP_SIZE;
                break;
            case 'W':
                player.x = (player.x - 1 + MAP_SIZE) % MAP_SIZE;
                break;
            default:
                break;
        }
        
        cout << map[player.x][player.y]->visit(player) << endl;
        
        player.takeTurn();
        cout << player.getStats() << endl;
        
    }
    
    cout << "You died." << endl;
    cout << "You earned a score of " << player.getScore() << endl;
    
    return 0;
}