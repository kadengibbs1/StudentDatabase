#include <iostream>

using namespace std;


template<typename T>
struct Node{
    T data;
    Node<T>* next = nullptr;
    Node<T>* prev = nullptr;
    Node (T val){
        data = val;
    }
};

template<typename T>
class DoublyLinkedList{
    public:
    
    // Default constructor
    DoublyLinkedList() = default;
    // Deconstructor
    ~DoublyLinkedList(){
        Node<T>* temp = head;
        while(temp != nullptr){
            Node<T>* next = temp->next;
            delete temp;
            temp = next;
        }
    }
    // Copy constructor
    DoublyLinkedList(const DoublyLinkedList& listCopy){
        head = nullptr;
        tail = nullptr;
        listSize = 0;
        Node<T>* temp = listCopy.head;
        while(temp != nullptr){
            push(temp->data);
            temp = temp->next;
        }
    }
    // Copy assignment operator
    DoublyLinkedList& operator=(const DoublyLinkedList& listCopy){
        if(this != &listCopy){
            clear();
            Node<T>* temp = listCopy.head;
            while(temp != nullptr){
                push(temp->data);
                temp = temp->next;
            }
        }
        return *this;
    }
    // Clear function
    void clear(){
        Node<T>* temp = head;
        while(temp != nullptr){
            Node<T>* nextNode = temp->next;
            delete temp;
            temp = nextNode;
        }
    }
    // Push function
    void push(T data){
        Node<T>* newNode = new Node<T>(data);
        if(listSize == 0){
            head = newNode;
            tail = newNode;
        }
        else{
            tail->next = newNode;
            newNode->prev = tail;
            tail = newNode;
        }
        listSize++;
    }
    // Pop function
    void pop(){
        if(listSize == 0){
            cout << "The list is empty." << endl;
        }
        if(listSize == 1){
            delete head;
            head = nullptr;
            tail = nullptr;
            listSize = 0;
            return;
        }
        Node<T>* temp = tail->prev;
        delete tail;
        temp->next = nullptr;
        tail = temp;
        listSize--;
    }
    // Size function
    int getSize(){
        return listSize;
    }
    // Print function
    void print(){
        Node<T>* temp = head;
        while(temp != nullptr){
            cout << temp->data << " ";
            temp = temp->next;
        }
        cout << endl;
    }
    // At function
    T& at(int idx){
        if(idx < 0 || idx >= listSize){
            cout << "Not in range." << endl;
        }
        Node<T>* temp = head;
        for(int i = 0; i < idx; i++){
            temp = temp->next;
        }
        return temp->data;
    }
    // Insert function
    void insert(int data, int pos){
        if(pos < 0 || pos > listSize){
            cout << "Not within range." << endl;
        }
        Node<T>* newNode = new Node<T>(data);
        if(listSize == 0){
            head = newNode;
            tail = newNode;
        }
        else if(pos == 0){
            newNode->next = head;
            head->prev = newNode;
            head = newNode;
        }
        else if(pos == listSize){
            newNode->prev = tail;
            tail->next = newNode;
            tail = newNode;
        }
        else{
            Node<T>* currNode = head;
            for(int i = 0; i < pos - 1; i++){
                currNode = currNode->next;
            }
            newNode->next = currNode->next;
            newNode->prev = currNode;
            currNode->next->prev = newNode;
            currNode->next = newNode;
        }
        listSize++;
    }
    // Remove function
    void remove(int value){
        if(head == nullptr){
            return;
        }
        if(head->data == value){
            Node<T>* temp = head;
            head = head->next;
            if(head != nullptr){
                head->prev = nullptr;
            }
            delete temp;
            listSize--;
            return;
        }
        Node<T>* current = head;
        while(current != nullptr && current->data != value){
            current = current->next;
        }
        if(current != nullptr){
            Node<T>* prevNode = current->prev;
            prevNode->next = current->next;
            if(current->next != nullptr){
                current->next->prev = prevNode;
            }
            delete current;
            listSize--;
        }
    }
    
    
    
    private:
    Node<T>* head = nullptr;
    Node<T>* tail = nullptr;
    int listSize = 0;
};




template<typename T>
void test(){
    DoublyLinkedList<T> dll;
    
    dll.push(1);
    dll.push(2);
    dll.push(3);
    
    DoublyLinkedList<T> dllCopy = dll;
    
    dllCopy.push(4);
    dllCopy.remove(1);
    dllCopy.remove(0);
    dllCopy.insert(5, 1);
    
    dll.print();
    dllCopy.print();
    
    dll = dllCopy;
    dll.print();
};
int main(){
    test<int>();
    
    return 0;
}