#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <algorithm>
#include <cmath>

using namespace std;

int main(int argc, char* argv[]){
    ifstream inFS;
    ofstream outFS;
    vector <char> characterLower{'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'};
    vector <char> characterUpper{'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'};
    int move;
    int i;
    bool encryption = false;
    bool decryption = false;
    string inputFile;
    string outputFile;
    vector<char>::iterator point;
    string line;
    char letter;
    
    
    
    for(i = 0; i < argc; i++){
        if((argv[i])[0] == '-'){
            // Checks for -k
            if((argv[i])[1] == 'k'){
                move = (stoi(argv[i+1])) % 26;
            }
            // Checks for -e
            if((argv[i])[1] == 'e'){
                encryption = true;
            }
            // Checks for -d
            if((argv[i])[1] == 'd'){
                decryption = true;
            }
            // Checks for -i
            if((argv[i])[1] == 'i'){
                inputFile = argv[i+1];
            }
            // Checks for -o
            if((argv[i])[1] == 'o'){
                outputFile = argv[i+1];
            }
        }
    }
    
    inFS.open(inputFile);
    // Tests to see if the input file is open
    if(!inFS.is_open()){
        cout << "Failed to open input file." << endl;
        return 1;
    }
    
    outFS.open(outputFile);
    // Tests to see if the output file is open
    if(!outFS.is_open()){
        cout << "Failed to open output file." << endl;
        return 1;
    }
    
    // Preforms encrytion
    if(encryption == true){
        getline(inFS, line);
        while(!inFS.fail()){
            for (int k = 0; k < line.size(); k++){
                letter = line.at(k);
                    if(isupper(letter)){
                        point = find(characterUpper.begin(), characterUpper.end(), letter);
                        letter = characterUpper.at((point - characterUpper.begin() + move) % 26);
                    }
                    if(islower(letter)){
                        point = find(characterLower.begin(), characterLower.end(), letter);
                        letter = characterLower.at((point - characterLower.begin() + move) % 26);
                    }
            outFS << letter;
            }
        outFS << endl;
        getline(inFS, line);
        }
    }
    
    // Preforms decryption
    if(decryption == true){
        getline(inFS, line);
        while(!inFS.fail()){
            for (int k = 0; k < line.size(); k++){
                letter = line.at(k);
                    if(isupper(letter)){
                        point = find(characterUpper.begin(), characterUpper.end(), letter);
                        letter = characterUpper.at((point - characterUpper.begin() - move + 26) % 26);
                    }
                    if(islower(letter)){
                        point = find(characterLower.begin(), characterLower.end(), letter);
                        letter = characterLower.at((point - characterLower.begin() - move + 26) % 26);
                    }
            outFS << letter;
        }
        outFS << endl;
        getline(inFS, line);
        }
    }
    
    inFS.close();
    outFS.close();
    
    return 0;
}