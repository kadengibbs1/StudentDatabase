#include "complex.h"

using namespace std;

Complex::Complex(double r, double i){
        real = r;
        imaginary = i;
    }
    
    void Complex::print(){
        cout << real << " + " << imaginary <<"i" << endl;
    }

Complex Complex::add(Complex c){
        Complex result(0,0);
        result.real = real + c.real;
        result.imaginary = imaginary + c.imaginary;
        return result;
    }
    
    Complex Complex::operator+(const Complex& c){
        Complex result(0,0);
        result.real = real + c.real;
        result.imaginary = imaginary + c.imaginary;
        return result;
    }
    
    Complex Complex::operator-(const Complex& c){
        Complex result(0,0);
        result.real = real - c.real;
        result.imaginary = imaginary - c.imaginary;
        return result;
    }
    
    void Complex::addToMyself(const Complex& c){
        real += c.real;
        imaginary += c.imaginary;
    }
    
    void Complex::operator+=(const Complex& c){
        real += c.real;
        imaginary += c.imaginary;
    }