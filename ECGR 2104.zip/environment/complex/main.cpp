//3+5i
#include <iostream>
#include "complex.h"

using namespace std;

int main(){
    Complex c1(3.0, 5.0);
    Complex c2(2.5, 1.5);
    
    c1.print();
    c2.print();
    
    
    Complex c4(0,0);
    
    
    //same as the next line
    //c4 = c1.add(c2);
    c4 = c1 + c2;
    c4 = c1 - c2;
    
    c4 += c1;
    
    c4.print();
    
    
    return 0;
}