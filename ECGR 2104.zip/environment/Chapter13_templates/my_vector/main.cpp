#include <iostream> 

using namespace std;

class MyVector{
    public:
    MyVector(){
        nextIndex = 0;
        arraySize = 3;
        a = new int[arraySize];
    }
    
    ~MyVector(){
        cout << "Destructor called" << endl;
        delete[] a;
    }
    
    void operator =(const MyVector& rhs){
        cout << "Assignment operator override called." << endl;
        delete[] a;
        
        nextIndex = rhs.nextIndex;
        arraySize = rhs.arraySize;
        
        a = new int[arraySize];
        for (int i = 0; i < nextIndex; i++){
            a[i] = rhs.a[i];
        }
    }
    
    void push_back(int val){
        if(nextIndex == arraySize){
            cout << "Reallocation more space..." << endl;
            int* temp = new int[arraySize*2];
            for (int i = 0; i < arraySize; i++){
                temp[i] = a[i];
            }
            delete[] a;
            a = temp;
            arraySize=arraySize * 2;
        }
        a[nextIndex] = val;
        nextIndex++;
    }
    void pop_back(){
        nextIndex++;
    }
    int at(int index){
        return a[index];
    }
    int size(){
        return nextIndex;
    }
    
    int* a;

    
    private:
    int nextIndex;
    int arraySize;
};


void makesProblem(){
        MyVector v;
    
        v.push_back(10);
        v.push_back(8);
        v.push_back(5);
        v.push_back(7);
    
        v.pop_back();
        v.pop_back();
    
        for (int i = 0; i < v.size(); i++){
            cout << v.at(i) << endl;
        }
        
        MyVector v2;
        v2.push_back(10);
        v2.push_back(8);
        v2.push_back(5);
        v2.push_back(7);
        v2=v;
        
        cout << &v << endl;
        cout << v.a << endl;
        
        
        delete[] v.a;
    }


int main() {
    
    makesProblem();
    
    makesProblem();
    
    makesProblem();
    
    
    return 0;
}