#include <iostream>
#include <vector>

using namespace std;

class Employee{
    public:
    
    double getWage() {
        return wages;
    }
    void setWage(double wage1) {
        if(wage1 <= 0){
            cout << "Enter correct employees wage." << endl;
        }
        else {
            wages = wage1;
        }
    }
    string getName(){
        return name;
    }
    void setName(string name1){
        name = name1;
    }
    string getJob(){
        return job;
    }
    void setJob(string job1){
        job = job1;
    }
    
    
    private:
    double wages;
    string name;
    string job;
};


void printList(vector<Employee> employee1){
    int i;
    for (i = 0; i < employee1.size(); i++){
        cout << i + 1 << ")   " << employee1.at(i).getName();
        cout << " is the " << employee1.at(i).getJob();
        cout << " and makes $" << employee1.at(i).getWage() << " an hour" << endl;
    }
}
double totalWages(vector<Employee> employee1){
    double hours;
    double totalWageCost = 0;
    int i;
    for(i = 0; i < employee1.size(); i++){
        do{
            cout << "How many hours did " << employee1.at(i).getName() << " work this week" << endl;
            cin >> hours;
            } while(hours < 0);
        totalWageCost = totalWageCost + hours*employee1.at(i).getWage();
    }
    cout << "$" << totalWageCost << " is due this week" << endl;
}



int main(){
    int selection;
    bool cont = true;
    
    cout << "Hello. This application will employee's names, job titles, and wages.";
    cout << " Please follow all directions." << endl;
    
    vector<Employee> employees;
    
    Employee e1;
    e1.setName("Toto Wolff");
    e1.setJob("Mercades F-1 Owner");
    e1.setWage(1000.00);
    
    Employee e2;
    e2.setName("Peter Bonnington");
    e2.setJob("Hamilton's Race Engineer");
    e2.setWage(700.00);
    
    Employee e3;
    e3.setName("Andrew Shovlin");
    e3.setJob("Russell's Race Engineer");
    e3.setWage(700.00);
    
    Employee e4;
    e4.setName("Lewis Hamilton");
    e4.setJob("Formula One Driver");
    e4.setWage(825.00);
    
    Employee e5;
    e5.setName("George Russell");
    e5.setJob("Formula One Driver");
    e5.setWage(825.00);
    
    employees.push_back(e1);
    employees.push_back(e2);
    employees.push_back(e3);
    employees.push_back(e4);
    employees.push_back(e5);
    
    do { 
    cout << "Please enter the number associated with what you would like to do." << endl;
    cout << "1)  Print list of employees" << endl;
    cout << "2)  Calculate total wages" << endl;
    cout << "3)  Exit application" << endl;
    cin >> selection;
    while (selection < 1 || selection > 3){
        cout << "Please enter the correct number associated with what you would like to do." << endl;
        cout << "1)  Print list of employees" << endl;
        cout << "2)  Calculate total wages" << endl;
        cout << "3)  Exit application" << endl;
        cin >> selection;
    }
    if(selection == 1){
        printList(employees);
        cout << endl << endl << endl;
    }
    else if (selection == 2){
        totalWages(employees);
        cont = false;
    }
    else{
        cont = false;
    }
    } while(cont);
    
    return 0;
}