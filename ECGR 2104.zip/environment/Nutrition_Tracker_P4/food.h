#ifndef FOOD_H
#define FOOD_H
#include <iostream>

using namespace std;

class Food{
    public:
    Food operator + (Food const &obj);
    string getFoodName();
    void setFoodName(string foodName1);
    int getCalories();
    void setCalories(int calories1);
    int getFat();
    void setFat(int fat1);
    int getSugar();
    void setSugar(int sugar1);
    int getProtein();
    void setProtein(int protein1);
    int getSodium();
    void setSodium (int sodium1);
    
    private:
    string foodName;
    int calories;
    int fat;
    int sugar;
    int protein;
    int sodium;
};
#endif