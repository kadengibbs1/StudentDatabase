#include "food.h"

using namespace std;

    Food Food::operator + (Food const &obj){
        Food t;
        t.calories = calories + obj.calories;
        t.fat = fat + obj.fat;
        t.sugar = sugar + obj.sugar;
        t.protein = protein + obj.protein;
        t.sodium = sodium + obj.sodium;
        return t;
    }
    string Food::getFoodName(){
        return foodName;
    }
    void Food::setFoodName(string foodName1){
        foodName = foodName1;
    }
    int Food::getCalories(){
        return calories;
    }
    void Food::setCalories(int calories1){
        calories = calories1;
    }
    int Food::getFat(){
        return fat;
    }
    void Food::setFat(int fat1){
        fat = fat1;
    }
    int Food::getSugar(){
        return sugar;
    }
    void Food::setSugar(int sugar1){
        sugar = sugar1;
    }
    int Food::getProtein(){
        return protein;
    }
    void Food::setProtein(int protein1){
        protein = protein1;
    }
    int Food::getSodium(){
        return sodium;
    }
    void Food::setSodium (int sodium1){
        sodium = sodium1;
    }