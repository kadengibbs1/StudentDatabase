#include <iostream>
#include <vector>
#include "food.h"

using namespace std;

int main(){
    bool cont=true;
    int foodNumber;
    
    vector <Food> foodList;
    
    // total
    Food f0;
    f0.setFoodName("Total");
    f0.setCalories(0);
    f0.setFat(0);
    f0.setSugar(0);
    f0.setProtein(0);
    f0.setSodium(0);
    
    Food f1;
    f1.setFoodName("Sausage");
    f1.setCalories(10);
    f1.setFat(10);
    f1.setSugar(10);
    f1.setProtein(10);
    f1.setSodium(10);
    
    Food f2;
    f2.setFoodName("Corn");
    f2.setCalories(20);
    f2.setFat(20);
    f2.setSugar(20);
    f2.setProtein(20);
    f2.setSodium(20);
    
    Food f3;
    f3.setFoodName("Pasta");
    f3.setCalories(30);
    f3.setFat(30);
    f3.setSugar(30);
    f3.setProtein(30);
    f3.setSodium(30);
    
    Food f4;
    f4.setFoodName("Chicken Nuggets");
    f4.setCalories(40);
    f4.setFat(40);
    f4.setSugar(40);
    f4.setProtein(40);
    f4.setSodium(40);
    
    Food f5;
    f5.setFoodName("Pizza");
    f5.setCalories(50);
    f5.setFat(50);
    f5.setSugar(50);
    f5.setProtein(50);
    f5.setSodium(50);
    
    Food f6;
    f6.setFoodName("Burger");
    f6.setCalories(60);
    f6.setFat(60);
    f6.setSugar(60);
    f6.setProtein(60);
    f6.setSodium(60);
    
    Food f7;
    f7.setFoodName("Donuts");
    f7.setCalories(70);
    f7.setFat(70);
    f7.setSugar(70);
    f7.setProtein(70);
    f7.setSodium(70);
    
    Food f8;
    f8.setFoodName("Popcorn");
    f8.setCalories(80);
    f8.setFat(80);
    f8.setSugar(80);
    f8.setProtein(80);
    f8.setSodium(80);
    
    Food f9;
    f9.setFoodName("Doritos");
    f9.setCalories(90);
    f9.setFat(90);
    f9.setSugar(90);
    f9.setProtein(90);
    f9.setSodium(90);
    
    Food f10;
    f10.setFoodName("French Fries");
    f10.setCalories(100);
    f10.setFat(100);
    f10.setSugar(100);
    f10.setProtein(100);
    f10.setSodium(100);
    
    foodList.push_back(f1);
    foodList.push_back(f2);
    foodList.push_back(f3);
    foodList.push_back(f4);
    foodList.push_back(f5);
    foodList.push_back(f6);
    foodList.push_back(f7);
    foodList.push_back(f8);
    foodList.push_back(f9);
    foodList.push_back(f10);
    
    do{
        for(int i = 0; i < 10; i++){
                cout << i+1 << ")   " << foodList.at(i).getFoodName() << endl;
            }
        cout << "Select a food to add. Input 11 to end the program." << endl;
        cin >> foodNumber;
        if (foodNumber == 11){
            break;
        }
        while (foodNumber < 1 || foodNumber > 11){
            cout << "Input the correct number of food you eat. Input 11 to finish the program." << endl;
            for(int i = 0; i < 10; i++){
                cout << i+1 << ")   " << foodList.at(i).getFoodName() << endl;
            }
            cin >> foodNumber;
        }
        if (foodNumber == 11){
                break;
            }
        f0 = f0 + foodList.at(foodNumber - 1);
    } while (cont);
    
    cout << "Total Energy: " << f0.getCalories() << "calories" << endl;
    cout << "Total Fat: " << f0.getFat() << "g" << endl;
    cout << "Total Sugar: " << f0.getSugar() << "g" << endl;
    cout << "Total Proein: " << f0.getSugar() << "g" << endl;
    cout << "Total Sodium: " << f0.getSodium() << "mg" << endl;
    
    if (f0.getCalories() > 2000){
        cout << "You exceeded the recommended calorie intake." << endl;
    }
    if (f0.getFat() > 70){
        cout << "You exceeded the recommended fat intake." << endl;
    }
    if (f0.getSugar() > 30){
        cout << "You exceeded the recommended sugar intake." << endl;
    }
    if (f0.getProtein() > 50){
        cout << "You exceeded the recommended protein intake." << endl;
    }
    if (f0.getSodium() > 2300){
        cout << "You exceeded the recommended sodium intake." << endl;
    }
    
    return 0;
}